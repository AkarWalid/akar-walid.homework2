
package homework2.akar.walid;

import java.util.Scanner;


public class Homework2AkarWalid {

    
    public static void main(String[] args) {
          Scanner scanner = new Scanner(System.in);
        RealEstateAgency agency = new RealEstateAgency();

        while (true) {
            System.out.println("Real Estate Agency");
            System.out.println("1. Add Property");
            System.out.println("2. Display All Properties");
            System.out.println("3. Remove Property (Sold) by House Number");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            if (choice == 1) {
                System.out.println("Enter Property Details");

                // General property details
                System.out.print("House Number: ");
                String houseNumber = scanner.nextLine();  // House number input
                System.out.print("Area (m²): ");
                double area = scanner.nextDouble();
                System.out.print("Number of Rooms: ");
                int rooms = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                System.out.print("Neighborhood: ");
                String neighborhood = scanner.nextLine();
                System.out.print("Price ($): ");
                double price = scanner.nextDouble();

                // Property type selection
                System.out.println("Choose property type: ");
                System.out.println("1. Villa");
                System.out.println("2. Apartment");
                System.out.println("3. Furnished Apartment");
                int propertyType = scanner.nextInt();

                // Create property based on the type chosen
                Property property = null;
                if (propertyType == 1) {
                    System.out.print("Has Swimming Pool (true/false): ");
                    boolean hasPool = scanner.nextBoolean();
                    System.out.print("Number of Adjacent Streets: ");
                    int numAdjacentStreets = scanner.nextInt();
                    property = new Villa(area, rooms, neighborhood, price, houseNumber, hasPool, numAdjacentStreets);
                } else if (propertyType == 2) {
                    System.out.print("Floor Number: ");
                    int floor = scanner.nextInt();
                    System.out.print("Has Parking (true/false): ");
                    boolean hasParking = scanner.nextBoolean();
                    property = new Apartment(area, rooms, neighborhood, price, houseNumber, floor, hasParking);
                } else if (propertyType == 3) {
                    System.out.print("Furniture Quality (1 to 5): ");
                    int furnitureQuality = scanner.nextInt();
                    property = new FurnishedApartment(area, rooms, neighborhood, price, houseNumber, furnitureQuality);
                }

                if (property != null) {
                    agency.addProperty(property);
                }
            } else if (choice == 2) {
                agency.displayProperties();
            } else if (choice == 3) {
                System.out.print("Enter the house number of the property to remove: ");
                String houseNumber = scanner.nextLine();  // House number input
                agency.removeProperty(houseNumber);
            } else if (choice == 4) {
                System.out.println("Exiting...");
                break;
            } else {
                System.out.println("Invalid choice. Please try again.");
            }
        }

        scanner.close();
    }
}