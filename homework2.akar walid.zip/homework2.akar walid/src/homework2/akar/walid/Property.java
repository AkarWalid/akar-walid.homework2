/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package homework2.akar.walid;

public class Property {
    protected double area;
    protected int rooms;
    protected String neighborhood;
    protected double price;
    protected String houseNumber;  // Added house number

    // Constructor to initialize Property attributes
    public Property(double area, int rooms, String neighborhood, double price, String houseNumber) {
        this.area = area;
        this.rooms = rooms;
        this.neighborhood = neighborhood;
        this.price = price;
        this.houseNumber = houseNumber;  // Initialize house number
    }

    // Display method to print property details
    public void display() {
        System.out.println("House Number: " + houseNumber + "\nType: Property\nArea: " + area + "m²\nRooms: " + rooms + "\nNeighborhood: " + neighborhood + "\nPrice: $" + price);
    }

    // Get house number
    public String getHouseNumber() {
        return houseNumber;
    }
}
