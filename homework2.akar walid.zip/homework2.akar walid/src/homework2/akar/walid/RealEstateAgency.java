/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package homework2.akar.walid;
public class RealEstateAgency {
    private Property[] properties;
    private int propertyCount;

    // Constructor to initialize the property array
    public RealEstateAgency() {
        properties = new Property[100];  // Maximum of 100 properties
        propertyCount = 0;
    }

    // Add property to the list
    public void addProperty(Property p) {
        if (propertyCount < 100) {
            properties[propertyCount++] = p;
            System.out.println("Property added successfully!\n");
        } else {
            System.out.println("Cannot add more properties. Maximum limit reached.");
        }
    }

    // Remove a property (sold) by house number
    public void removeProperty(String houseNumber) {
        boolean found = false;
        for (int i = 0; i < propertyCount; i++) {
            if (properties[i].getHouseNumber().equals(houseNumber)) {
                // Shift properties to the left
                for (int j = i; j < propertyCount - 1; j++) {
                    properties[j] = properties[j + 1];
                }
                properties[propertyCount - 1] = null;  // Clear the last property
                propertyCount--;
                System.out.println("Property with house number " + houseNumber + " sold and removed from the list.\n");
                found = true;
                break;
            }
        }
        if (!found) {
            System.out.println("Property with house number " + houseNumber + " not found.\n");
        }
    }

    // Display all properties
    public void displayProperties() {
        if (propertyCount == 0) {
            System.out.println("No properties available.");
        } else {
            for (int i = 0; i < propertyCount; i++) {
                properties[i].display();
                System.out.println();
            }
        }
    }
}
