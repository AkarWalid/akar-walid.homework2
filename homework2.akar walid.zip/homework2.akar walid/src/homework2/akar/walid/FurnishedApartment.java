/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package homework2.akar.walid;

public class FurnishedApartment extends Property {
    private int furnitureQuality;

    // Constructor to initialize FurnishedApartment attributes
    public FurnishedApartment(double area, int rooms, String neighborhood, double price, String houseNumber, int furnitureQuality) {
        super(area, rooms, neighborhood, price, houseNumber);
        this.furnitureQuality = furnitureQuality;
    }

    // Override display method to include FurnishedApartment specific details
    @Override
    public void display() {
        super.display();
        System.out.println("Furniture Quality: " + furnitureQuality);
    }
}
