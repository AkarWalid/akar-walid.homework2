/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package homework2.akar.walid;


public class Villa extends Property {
    private boolean hasPool;
    private int numAdjacentStreets;

    // Constructor to initialize Villa attributes
    public Villa(double area, int rooms, String neighborhood, double price, String houseNumber, boolean hasPool, int numAdjacentStreets) {
        super(area, rooms, neighborhood, price, houseNumber);
        this.hasPool = hasPool;
        this.numAdjacentStreets = numAdjacentStreets;
    }

    // Override display method to include Villa specific details
    @Override
    public void display() {
        super.display();
        System.out.println("Has Swimming Pool: " + (hasPool ? "Yes" : "No") + "\nAdjacent Streets: " + numAdjacentStreets);
    }
}
